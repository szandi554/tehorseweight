# Ló súlyának becslése

Ló súlyána becslése a mellkas kerülete és a hossza alpján.

Az alkalmazás egy webes felület, JavaScriptben megvalósítva.

Az alkalmazás a következő feladat megoldása:

* [https://szit.hu/doku.php?id=oktatas:programozas:feladatok:altalanos#feladat_0375](https://szit.hu/doku.php?id=oktatas:programozas:feladatok:altalanos#feladat_0375)

A feladatleírásban talál egy képletet. A képlet segítségével vegyen fel teszteseteket. Végezze el a tesztelést.

A tesztelendő a tools.js fájlban található függvény.

## Használataba vétel

```cmd
git clone https://github.com/oktat/tehorseweight
cd tehorseweight
npm install
npm start
```

## Licenc

* MIT licenc
